# Press Kit for chordlist

Last synchronized from Kickstart MCP: 1 August 2026

## Contact

Name: Dennis Muensterer  
Email: support@chordlist.app

## App Details

Name: chordlist  
Tagline: Your lyrics and chords, as files!  
Launch Date: 30 August 2026  
Price: Free download with an optional one-time unlock for unlimited songs; final pricing to be announced  
Minimum OS: iOS or iPadOS 18.0 or later

## Description

# Introducing chordlist: Your Personal Songbook, Stored as Markdown

chordlist is an upcoming iPhone and iPad app for hobbyist musicians who want a simple, portable place for the songs they play. Each song is stored as a Markdown file with its title, artist, chords, tags, and lyrics, keeping the library readable and under the musician's control.

## Availability

chordlist is built natively for iPhone and iPad and requires iOS or iPadOS 18 or later. An Android version is not currently planned.

The app is available as a free download with a library of up to 10 songs and an optional one-time unlock for unlimited songs. Final pricing will be announced closer to launch.

## Key Features

- Markdown-based personal song library
- Chord matching for songs with similar progressions
- Search, tag filters, and shuffle
- Chord transposition and automatic scrolling
- In-app song creation and import

## About the Developer

Dennis Muensterer is an independent app developer building software under the brand “makerer studio”. They have experience shipping apps from idea to release and care about clean, maintainable software. chordlist is planned for release on 30 August 2026.

## Additional Notes

No Android version is currently planned. Pricing is not final and should be announced closer to launch.

## Additional Images

- `01-Song-List---4-Chord-Library.png`
- `02-Song-Detail---Matching-Suggestions.png`
- `03-Creation-Flow---New-Song.png`

## Assets Available

- App Icon: No
- Developer Logo: Yes
- Additional Images: 3
- Article References: 0
